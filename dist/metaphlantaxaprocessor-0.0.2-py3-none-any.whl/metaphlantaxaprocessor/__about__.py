# SPDX-FileCopyrightText: 2025-present vidyasagar0405 <vidyasagar0405@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.2"
