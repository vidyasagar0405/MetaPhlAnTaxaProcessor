import unittest
from unittest.mock import patch, mock_open
import os
import pandas as pd
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src')))
from metaphlantaxaprocessor.utils import combine_csv_to_xlsx, process_all_ranks, check_and_create_dir
from metaphlantaxaprocessor.process_rank import process_rank


class TestProcessingFunctions(unittest.TestCase):

    @patch("os.makedirs")
    @patch("os.path.exists")
    def test_check_and_create_dir(self, mock_exists, mock_makedirs):
        # Test when directory exists
        mock_exists.return_value = True
        check_and_create_dir("output_dir")
        mock_makedirs.assert_not_called()

        # Test when directory does not exist
        mock_exists.return_value = False
        check_and_create_dir("output_dir")
        mock_makedirs.assert_called_once_with("output_dir")

    @patch("builtins.open", new_callable=mock_open, read_data="k__Bacteria\t0.35\tother_data\n")
    @patch("csv.writer")
    def test_process_rank(self, mock_writer, mock_open):
        infile = "test_input.tsv"
        outdir = "output"
        rank = "Kingdom"
        include = "k__"
        exclude = "p__"
        remove_pattern = "k__"

        process_rank(infile, outdir, rank, include, exclude, remove_pattern)

        # Check if the CSV file is written
        mock_open.assert_called_once_with(os.path.join(outdir, "kingdom.csv"), "w", newline="", encoding="utf-8")
        mock_writer.return_value.writerow.assert_any_call(["Kingdom", "Relative_abundance", "OUT"])
        mock_writer.return_value.writerows.assert_any_call([["Bacteria", "0.35", "k__Bacteria"]])

    @patch("pandas.ExcelWriter")
    @patch("os.path.exists")
    @patch("pandas.read_csv")
    def test_combine_csv_to_xlsx(self, mock_read_csv, mock_exists, mock_excel_writer):
        outdir = "output"
        prefix = "input_file"
        levels = [("Kingdom", "k__"), ("Phyla", "p__")]

        mock_exists.return_value = True
        mock_read_csv.return_value = pd.DataFrame([["Bacteria", "0.35", "k__Bacteria"]])

        combine_csv_to_xlsx(outdir, prefix, levels)

        # Ensure ExcelWriter was called with the right file name
        mock_excel_writer.assert_called_once_with(os.path.join(outdir, "input_file-taxa.xlsx"), engine="openpyxl")

    @patch("builtins.open", new_callable=mock_open, read_data="k__Bacteria\t0.35\tother_data\n")
    @patch("csv.writer")
    def test_process_all_ranks(self, mock_writer, mock_open):
        infile = "test_input.tsv"
        outdir = "output"
        levels = [
            ("Kingdom", "k__", "p__"),
            ("Phyla", "p__", "c__")
        ]

        process_all_ranks(infile, outdir, levels)

        # Check if the correct process_rank function is called for each taxonomic level
        mock_open.assert_called_with(infile, "r", encoding="utf-8")
        mock_writer.return_value.writerow.assert_any_call(["Kingdom", "Relative_abundance", "OUT"])
        mock_writer.return_value.writerows.assert_any_call([["Bacteria", "0.35", "k__Bacteria"]])


if __name__ == "__main__":
    unittest.main()
