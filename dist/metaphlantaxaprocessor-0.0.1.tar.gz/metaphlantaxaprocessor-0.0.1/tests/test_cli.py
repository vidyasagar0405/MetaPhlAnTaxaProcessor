import unittest
from unittest.mock import patch
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src')))
from metaphlantaxaprocessor import main


class TestCLI(unittest.TestCase):

    @patch("builtins.print")
    @patch("os.path.isfile")
    @patch("os.makedirs")
    @patch("metaphlantaxaprocessor.process_all_ranks")
    @patch("metaphlantaxaprocessor.combine_csv_to_xlsx")
    def test_cli_with_combine(self, mock_combine, mock_process, mock_makedirs, mock_isfile, mock_print):
        # Mock file existence check
        mock_isfile.return_value = True
        mock_process.return_value = None
        mock_combine.return_value = None

        # Simulate the command line args
        test_args = ["script_name", "test_input.tsv", "--outdir", "output_dir", "--combine"]
        with patch.object(sys, 'argv', test_args):
            main()

        # Verify that the correct functions were called
        mock_process.assert_called_once()
        mock_combine.assert_called_once()

    @patch("builtins.print")
    @patch("os.path.isfile")
    @patch("os.makedirs")
    @patch("metaphlantaxaprocessor.process_all_ranks")
    def test_cli_without_combine(self, mock_process, mock_makedirs, mock_isfile, mock_print):
        # Mock file existence check
        mock_isfile.return_value = True
        mock_process.return_value = None

        # Simulate the command line args
        test_args = ["script_name", "test_input.tsv", "--outdir", "output_dir"]
        with patch.object(sys, 'argv', test_args):
            main()

        # Verify that combine was not called
        mock_process.assert_called_once()


if __name__ == "__main__":
    unittest.main()
